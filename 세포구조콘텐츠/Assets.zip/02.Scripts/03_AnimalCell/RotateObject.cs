using UnityEngine;

public class RotateObject : MonoBehaviour
{

    [SerializeField]
    float rotationSpeed = 100f;
    bool dragging = false;
    Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void OnMouseDrag()
    {
        dragging = true;
    }

    void Update()
    {
        if (Input.GetMouseButtonUp(0))
        {
            dragging = false;
        }
    }
    void FixedUpdate()
    {
        if (dragging)
        {
            float x = Input.GetAxis("Mouse X") * rotationSpeed * 100 * Time.fixedDeltaTime;
            float y = Input.GetAxis("Mouse Y") * rotationSpeed * 100 * Time.fixedDeltaTime;

            rb.AddTorque(Vector3.down * x);
            rb.AddTorque(Vector3.right * y);

        }
    }
}
