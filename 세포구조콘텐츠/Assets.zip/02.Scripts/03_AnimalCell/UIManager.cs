using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIManager : MonoBehaviour
{

    public GameObject _optionPanel;

    public void OnClickOptionOpen()
    {
        _optionPanel.SetActive(true);
        Time.timeScale = 0f;
    }

    public void OnClickOptionClose()
    {
        _optionPanel.SetActive(false);
        Time.timeScale = 1f;
    }

}
