using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public void LoadScene00()
    {
        SceneManager.LoadScene(0);
    }

    public void LoadScene01()
    {
        SceneManager.LoadScene(1);
    }

    public void LoadScene02()
    {
        SceneManager.LoadScene(2);
    }

    public void LoadScene03()
    {
        SceneManager.LoadScene(3);
    }

    public void LoadScene04()
    {
        SceneManager.LoadScene(4);
    }

    public void ExitGame()
    {
        Application.Quit();
    }
}
